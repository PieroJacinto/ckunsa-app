import * as universal from "../../../../src/routes/palabra/[id]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/palabra/[id]/+page.svelte";