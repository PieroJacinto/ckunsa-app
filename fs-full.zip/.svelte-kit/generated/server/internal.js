
import root from '../root.js';
import { set_building, set_prerendering } from '$app/env/internal';
import { set_assets } from '$app/paths/internal/server';
import { set_manifest, set_read_implementation } from '__sveltekit/server';
import { set_private_env, set_public_env } from '../../../node_modules/@sveltejs/kit/src/runtime/shared-server.js';
import error from '../shared/error-template.js';

export const options = {
	app_template_contains_nonce: false,
	async: false,
	csp: {"mode":"auto","directives":{"upgrade-insecure-requests":false,"block-all-mixed-content":false},"reportOnly":{"upgrade-insecure-requests":false,"block-all-mixed-content":false}},
	csrf_check_origin: true,
	csrf_trusted_origins: [],
	embedded: false,
	env_public_prefix: 'PUBLIC_',
	env_private_prefix: '',
	hash_routing: false,
	hooks: null, // added lazily, via `get_hooks`
	preload_strategy: "modulepreload",
	root,
	service_worker: false,
	service_worker_options: undefined,
	server_error_boundaries: false,
	templates: {
		app: ({ head, body, assets, nonce, env }) => "<!doctype html>\n<html lang=\"es\">\n\t<head>\n\t\t<meta charset=\"utf-8\" />\n\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n\t\t<meta name=\"text-scale\" content=\"scale\" />\n\t\t<meta name=\"google\" content=\"notranslate\" />\n\t\t<script>\n\t\t\t/*\n\t\t\t\tEl navegador dispara `beforeinstallprompt` al cargar la página, mucho\n\t\t\t\tantes de que Svelte monte ningún componente. Si se escucha desde un\n\t\t\t\tcomponente, el evento ya pasó y no lo agarra nadie: el botón de\n\t\t\t\tinstalar no aparece nunca, aunque el navegador sí ofrezca instalar.\n\n\t\t\t\tPor eso se captura acá, lo más temprano posible, y se guarda para que\n\t\t\t\tel componente lo use cuando esté listo.\n\t\t\t*/\n\t\t\twindow.__promptInstalacion = null;\n\t\t\twindow.addEventListener('beforeinstallprompt', function (e) {\n\t\t\t\te.preventDefault();\n\t\t\t\twindow.__promptInstalacion = e;\n\t\t\t\twindow.dispatchEvent(new Event('ck:instalable'));\n\t\t\t});\n\t\t</script>\n\t\t" + head + "\n\t</head>\n\t<body data-sveltekit-preload-data=\"hover\">\n\t\t<div style=\"display: contents\">" + body + "</div>\n\t</body>\n</html>\n",
		error
	},
	version_hash: "1zrc1o"
};

export async function get_hooks() {
	let handle;
	let handleFetch;
	let handleError;
	let handleValidationError;
	let init;
	

	let reroute;
	let transport;
	

	return {
		handle,
		handleFetch,
		handleError,
		handleValidationError,
		init,
		reroute,
		transport
	};
}

export { set_assets, set_building, set_manifest, set_prerendering, set_private_env, set_public_env, set_read_implementation };
