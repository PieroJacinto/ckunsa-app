

export const index = 5;
export const imports = ["_app/immutable/nodes/5.C-9BbvuL.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/9XmckqWT.js","_app/immutable/chunks/b9tJ7_6y.js","_app/immutable/chunks/Dt5synmc.js","_app/immutable/chunks/BBJuZS4R.js","_app/immutable/chunks/C1j15SML.js"];
export const stylesheets = [];
export const fonts = [];
