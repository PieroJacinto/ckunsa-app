

export const index = 0;
export const universal = {
  "ssr": false,
  "prerender": true,
  "trailingSlash": "always"
};
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.egAXkyCL.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/9XmckqWT.js","_app/immutable/chunks/b9tJ7_6y.js","_app/immutable/chunks/Dt5synmc.js"];
export const stylesheets = ["_app/immutable/assets/0.Dkt73cDb.css"];
export const fonts = [];
