

export const index = 8;
export const universal = {
  "ssr": false,
  "prerender": false,
  "trailingSlash": "always"
};
export const universal_id = "src/routes/palabra/[id]/+page.ts";
export const imports = ["_app/immutable/nodes/8.xIUkhR8l.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/b9tJ7_6y.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/Dt5synmc.js","_app/immutable/chunks/BBJuZS4R.js","_app/immutable/chunks/DaUWanm7.js","_app/immutable/chunks/C1j15SML.js"];
export const stylesheets = [];
export const fonts = [];
