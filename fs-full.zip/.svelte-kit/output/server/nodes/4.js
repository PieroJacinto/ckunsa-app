

export const index = 4;
export const imports = ["_app/immutable/nodes/4.DMyN7NHV.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/b9tJ7_6y.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/BBJuZS4R.js","_app/immutable/chunks/CpYs_o7w.js"];
export const stylesheets = [];
export const fonts = [];
