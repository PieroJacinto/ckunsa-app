

export const index = 9;
export const imports = ["_app/immutable/nodes/9.BKwYkIMd.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/BBJuZS4R.js"];
export const stylesheets = [];
export const fonts = [];
