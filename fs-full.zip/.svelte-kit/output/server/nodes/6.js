

export const index = 6;
export const imports = ["_app/immutable/nodes/6.DhsfH8ND.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/BBJuZS4R.js"];
export const stylesheets = [];
export const fonts = [];
