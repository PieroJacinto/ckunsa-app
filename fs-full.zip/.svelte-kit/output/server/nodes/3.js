

export const index = 3;
export const imports = ["_app/immutable/nodes/3.DtaIoiCh.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Dt5synmc.js","_app/immutable/chunks/BBJuZS4R.js","_app/immutable/chunks/DaUWanm7.js"];
export const stylesheets = [];
export const fonts = [];
