

export const index = 1;
export const imports = ["_app/immutable/nodes/1.B0siEkFc.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/b9tJ7_6y.js","_app/immutable/chunks/Bi39FpoZ.js"];
export const stylesheets = [];
export const fonts = [];
