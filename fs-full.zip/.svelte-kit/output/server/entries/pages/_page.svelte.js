import "../../chunks/index-server.js";
import { b as escape_html, n as derived, o as stringify, r as ensure_array_like, y as attr } from "../../chunks/server.js";
import { i as goto, t as page } from "../../chunks/state.js";
import "../../chunks/navigation.js";
import { n as usarDiccionario, r as DESCRIPCION_MOTIVO } from "../../chunks/contexto.svelte.js";
import { t as AppViewLayout } from "../../chunks/AppViewLayout.js";
import { t as CitaFuente } from "../../chunks/CitaFuente.js";
import { n as DESCRIPCION_NIVEL, t as EvidenceBadge } from "../../chunks/EvidenceBadge.js";
//#region src/lib/componentes/BuscadorInput.svelte
function BuscadorInput($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Para el anuncio a lectores de pantalla. */
		let { valor, onBuscar, cantidadResultados, placeholder = "ckabur, montaña, agua…" } = $$props;
		const anuncio = derived(() => {
			if (valor.trim() === "" || cantidadResultados === void 0) return "";
			if (cantidadResultados === 0) return "Sin resultados";
			if (cantidadResultados === 1) return "1 resultado";
			return `${cantidadResultados} resultados`;
		});
		$$renderer.push(`<div class="buscador"><label class="buscador__etiqueta visualmente-oculto" for="buscador-consulta">Buscar en ckunsa o en español</label> <div class="buscador__campo"><svg class="buscador__lupa" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><circle cx="7" cy="7" r="4.5"></circle><path d="M10.5 10.5 14 14"></path></svg> <input id="buscador-consulta" class="buscador__input" type="search" autocomplete="off" spellcheck="false"${attr("placeholder", placeholder)}${attr("value", valor)}/> `);
		if (valor !== "") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="buscador__limpiar" type="button" title="Limpiar la búsqueda"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"></path></svg> <span class="visualmente-oculto">Limpiar la búsqueda</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <p class="buscador__anuncio visualmente-oculto" role="status" aria-live="polite">${escape_html(anuncio())}</p></div>`);
	});
}
//#endregion
//#region src/lib/componentes/EntradaCard.svelte
function EntradaCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Si viene, se cita en formato compacto. */
		/** Explicación puntual del buscador, más precisa que la genérica. */
		/**
		* Mostrar la nota de grafía provisional en esta tarjeta.
		*
		* Por defecto NO, porque en un listado la llevan las 851 entradas y una
		* advertencia que aparece en todos los ítems deja de informar (V4.1). El
		* listado la dice una vez arriba; la ficha de palabra la pasa en `true`.
		*/
		let { entrada, fuente, motivo, detalle, mostrarNotaGrafia = false } = $$props;
		const aviso = derived(() => motivo ? DESCRIPCION_MOTIVO[motivo] : null);
		$$renderer.push(`<article class="ficha"><h2 class="ficha__titulo"><a class="ficha__enlace"${attr("href", `/palabra/${stringify(entrada.id)}`)}>`);
		EvidenceBadge($$renderer, {
			nivel: entrada.nivel_evidencia,
			grafiaProvisional: mostrarNotaGrafia && entrada.grafia_provisional,
			children: ($$renderer) => {
				$$renderer.push(`<!---->${escape_html(entrada.forma_clck)}`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></a></h2> <p class="ficha__significados">${escape_html(entrada.significados.join(", "))}</p> `);
		if (entrada.campo_semantico) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__campo">${escape_html(entrada.campo_semantico)}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (aviso()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__coincidencia">${escape_html(detalle ?? aviso())}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (entrada.estado === "retirada") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__retirada">Esta forma fue retirada: ${escape_html(entrada.motivo_retiro)}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (fuente) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__fuente">`);
			CitaFuente($$renderer, {
				fuente,
				formato: "compacta"
			});
			$$renderer.push(`<!----></p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></article>`);
	});
}
//#endregion
//#region src/lib/componentes/BotonInstalar.svelte
function BotonInstalar($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const sePuedeInstalar = derived(() => false);
		const mostrarInstrucciones = derived(() => false);
		if (sePuedeInstalar() || mostrarInstrucciones()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="instalar"><p class="instalar__texto"><strong>Llevátelo en el teléfono</strong> para abrirlo como cualquier aplicación.</p> <div class="instalar__acciones">`);
			if (sePuedeInstalar()) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`<button class="instalar__boton" type="button">Instalar</button>`);
			} else {
				$$renderer.push("<!--[-1-->");
				$$renderer.push(`<a class="instalar__boton" href="/instalar">Cómo se hace</a>`);
			}
			$$renderer.push(`<!--]--> <button class="instalar__cerrar" type="button">Ahora no</button></div> <p class="instalar__nota">No hace falta instalarlo: acá en el navegador funciona igual, también sin conexión. Instalarlo
			sólo agrega el ícono en la pantalla.</p></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/lib/componentes/Bienvenida.svelte
function Bienvenida($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Llena el buscador con la palabra del ejemplo. */
		let { onEjemplo } = $$props;
		const NIVELES = [
			"atestiguada",
			"unificada",
			"reconstruida",
			"propuesta"
		];
		const EJEMPLOS = [
			{
				palabra: "cueva",
				porque: "dos palabras distintas para un mismo concepto"
			},
			{
				palabra: "luna",
				porque: "una palabra con dos significados"
			},
			{
				palabra: "cabur",
				porque: "una grafía antigua que igual encuentra"
			}
		];
		$$renderer.push(`<section class="bienvenida"><p class="bienvenida__intro">Diccionario de la lengua <strong>ckunsa</strong>, del pueblo lickanantay del Salar de Atacama.
		Es una lengua dormida: hace más de un siglo que no se registran hablantes fluidos, y casi todo
		lo que sabemos viene de anotaciones hechas por gente de afuera. Por eso <strong>cada palabra dice de dónde sale</strong>.</p> `);
		BotonInstalar($$renderer, {});
		$$renderer.push(`<!----> <h2 class="bienvenida__titulo">Probá con</h2> <div class="bienvenida__ejemplos"><!--[-->`);
		const each_array = ensure_array_like(EJEMPLOS);
		for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
			let ejemplo = each_array[$$index];
			$$renderer.push(`<button type="button" class="bienvenida__ejemplo"><span class="bienvenida__palabra">${escape_html(ejemplo.palabra)}</span> <span class="bienvenida__porque">${escape_html(ejemplo.porque)}</span></button>`);
		}
		$$renderer.push(`<!--]--></div> <h2 class="bienvenida__titulo">Qué significan las marcas</h2> <dl class="bienvenida__niveles"><!--[-->`);
		const each_array_1 = ensure_array_like(NIVELES);
		for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
			let nivel = each_array_1[$$index_1];
			$$renderer.push(`<dt>`);
			EvidenceBadge($$renderer, { nivel });
			$$renderer.push(`<!----></dt> <dd>${escape_html(DESCRIPCION_NIVEL[nivel])}</dd>`);
		}
		$$renderer.push(`<!--]--></dl> <p class="bienvenida__mas"><a href="/fuentes">De dónde salen estas palabras</a></p></section>`);
	});
}
//#endregion
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		const ESPERA = 300;
		let reloj;
		function alBuscar(consulta) {
			diccionario.buscar(consulta);
			clearTimeout(reloj);
			reloj = setTimeout(() => {
				const url = new URL(page.url);
				if (consulta.trim()) url.searchParams.set("q", consulta);
				else url.searchParams.delete("q");
				goto(url, {
					replaceState: true,
					noScroll: true,
					keepFocus: true
				});
			}, ESPERA);
		}
		const subtitulo = derived(() => diccionario.estado === "listo" ? `${diccionario.total} palabras` : void 0);
		AppViewLayout($$renderer, {
			titulo: "Diccionario ckunsa",
			subtitulo: subtitulo(),
			children: ($$renderer) => {
				BuscadorInput($$renderer, {
					valor: diccionario.consulta,
					onBuscar: alBuscar,
					cantidadResultados: diccionario.estado === "listo" ? diccionario.resultados.length : void 0
				});
				$$renderer.push(`<!----> `);
				if (diccionario.estado === "listo" && diccionario.resultados.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="aviso-grafia">Las formas están escritas en la grafía de sus fuentes. La normalización a la grafía unificada
			del Consejo Lingüístico Ckunsa está pendiente.</p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (diccionario.estado === "cargando" || diccionario.estado === "inicial") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="estado">Cargando el diccionario…</p>`);
				} else if (diccionario.estado === "error") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<p class="estado estado--error">No se pudieron cargar los datos. Revisá la conexión y volvé a intentar.</p>`);
				} else if (diccionario.consulta.trim() === "") {
					$$renderer.push("<!--[2-->");
					Bienvenida($$renderer, { onEjemplo: alBuscar });
				} else if (diccionario.resultados.length === 0) {
					$$renderer.push("<!--[3-->");
					$$renderer.push(`<p class="estado">No se encontró nada para «${escape_html(diccionario.consulta)}».</p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<ul class="resultados"><!--[-->`);
					const each_array = ensure_array_like(diccionario.resultados);
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let resultado = each_array[$$index];
						$$renderer.push(`<li>`);
						EntradaCard($$renderer, {
							entrada: resultado.entrada,
							fuente: diccionario.fuente(resultado.entrada.fuentes[0] ?? ""),
							motivo: resultado.motivo,
							detalle: resultado.detalle
						});
						$$renderer.push(`<!----></li>`);
					}
					$$renderer.push(`<!--]--></ul>`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
