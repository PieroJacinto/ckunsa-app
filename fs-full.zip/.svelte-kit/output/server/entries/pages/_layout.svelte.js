import "../../chunks/index-server.js";
import { b as escape_html, i as head, r as ensure_array_like, y as attr } from "../../chunks/server.js";
import { n as updated, r as beforeNavigate, t as page } from "../../chunks/state.js";
import "../../chunks/navigation.js";
import { n as usarDiccionario, t as proveerDiccionario } from "../../chunks/contexto.svelte.js";
//#region src/lib/componentes/AvisoActualizacion.svelte
function AvisoActualizacion($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/lib/componentes/NavPrincipal.svelte
function NavPrincipal($$renderer, $$props) {
	/** `page.url.pathname`, provisto por el layout raíz. */
	let { rutaActual } = $$props;
	const enlaces = [
		{
			href: "/",
			texto: "Buscar"
		},
		{
			href: "/indice",
			texto: "Índice"
		},
		{
			href: "/lengua",
			texto: "El ckunsa"
		},
		{
			href: "/proyecto",
			texto: "Proyecto"
		},
		{
			href: "/fuentes",
			texto: "Fuentes"
		}
	];
	function normalizar(ruta) {
		return ruta !== "/" && ruta.endsWith("/") ? ruta.slice(0, -1) : ruta;
	}
	$$renderer.push(`<nav class="vista__nav" aria-label="Principal"><!--[-->`);
	const each_array = ensure_array_like(enlaces);
	for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
		let enlace = each_array[$$index];
		const actual = normalizar(rutaActual) === enlace.href ? "page" : void 0;
		$$renderer.push(`<a class="vista__nav-enlace"${attr("href", enlace.href)}${attr("aria-current", actual)}>${escape_html(enlace.texto)}</a>`);
	}
	$$renderer.push(`<!--]--></nav>`);
}
//#endregion
//#region src/lib/componentes/EstadoConexion.svelte
function EstadoConexion($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/lib/componentes/AvisoDatos.svelte
function AvisoDatos($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		let aplicando = false;
		if (diccionario.hayActualizacion) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<div class="aviso-sw" role="status"><p class="aviso-sw__texto">Hay palabras nuevas en el diccionario.</p> <button class="aviso-sw__accion" type="button"${attr("disabled", aplicando, true)}>${escape_html("Actualizar")}</button></div>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/routes/+layout.svelte
function _layout($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { children } = $$props;
		proveerDiccionario();
		beforeNavigate(({ willUnload, to }) => {
			if (updated.current && !willUnload && to?.url) location.href = to.url.href;
		});
		head("12qhfyh", $$renderer, ($$renderer) => {
			$$renderer.push(`<link rel="icon" href="/favicon.svg"/> <link rel="manifest" href="/manifest.webmanifest"/> <meta name="theme-color" content="#8f4a22"/> <link rel="apple-touch-icon" href="/icono-192.png"/>`);
		});
		AvisoActualizacion($$renderer, {});
		$$renderer.push(`<!----> `);
		EstadoConexion($$renderer, {});
		$$renderer.push(`<!----> `);
		AvisoDatos($$renderer, {});
		$$renderer.push(`<!----> <div class="chrome">`);
		NavPrincipal($$renderer, { rutaActual: page.url.pathname });
		$$renderer.push(`<!----></div> `);
		children($$renderer);
		$$renderer.push(`<!---->`);
	});
}
//#endregion
export { _layout as default };
