import { b as escape_html, n as derived, o as stringify, r as ensure_array_like, y as attr } from "../../../chunks/server.js";
import { i as goto, t as page } from "../../../chunks/state.js";
import "../../../chunks/navigation.js";
import { i as normalizarSignificado, n as usarDiccionario } from "../../../chunks/contexto.svelte.js";
import { t as AppViewLayout } from "../../../chunks/AppViewLayout.js";
import { t as EvidenceBadge } from "../../../chunks/EvidenceBadge.js";
/** Saca la puntuación inicial: `¿dónde?` va en la D, no en un cajón aparte. */
function clave(glosa) {
	return normalizarSignificado(glosa).replace(/^[^a-z0-9]+/, "");
}
function letraDe(glosa) {
	const primera = clave(glosa).charAt(0).toUpperCase();
	return /^[A-Z]$/.test(primera) ? primera : "#";
}
/**
* Agrupa por letra inicial de la glosa española.
*
* Una entrada con varios significados aparece VARIAS veces, una por glosa:
* `ckamur` está en la L de "luna" y en la M de "mes". Es lo correcto en un
* índice: quien busca "mes" tiene que encontrarlo ahí. El glosario del CLCK
* hace lo mismo.
*
* Las entradas retiradas no aparecen (`03-MODELO-DE-DATOS` §5).
*/
function construirIndiceAlfabetico(corpus) {
	const porLetra = /* @__PURE__ */ new Map();
	for (const entrada of corpus.entradas) {
		if (entrada.estado === "retirada") continue;
		for (const glosa of entrada.significados) {
			const letra = letraDe(glosa);
			const lineas = porLetra.get(letra);
			if (lineas) lineas.push({
				glosa,
				entrada
			});
			else porLetra.set(letra, [{
				glosa,
				entrada
			}]);
		}
	}
	return [...porLetra.entries()].map(([letra, lineas]) => ({
		letra,
		lineas: lineas.sort((a, b) => clave(a.glosa).localeCompare(clave(b.glosa), "es") || a.entrada.forma_clck.localeCompare(b.entrada.forma_clck, "es"))
	})).sort((a, b) => {
		if (a.letra === "#") return 1;
		if (b.letra === "#") return -1;
		return a.letra.localeCompare(b.letra, "es");
	});
}
/**
* Agrupa por campo semántico.
*
* OJO con la atribución: estos campos son los 22 capítulos del cuestionario
* IDS, adaptados de Buck (1949). **No** son las categorías del CLCK, que tiene
* las suyas propias en su Atlas de la lengua —Familia, La lickana, Toponimia y
* apellidos locales, Medicina tradicional— y reflejan otras prioridades. La UI
* tiene que decir de dónde salen.
*/
function agruparPorCampoSemantico(corpus) {
	const porCampo = /* @__PURE__ */ new Map();
	for (const entrada of corpus.entradas) {
		if (entrada.estado === "retirada") continue;
		const campo = entrada.campo_semantico;
		if (!campo) continue;
		const lista = porCampo.get(campo);
		if (lista) lista.push(entrada);
		else porCampo.set(campo, [entrada]);
	}
	return [...porCampo.entries()].map(([campo, entradas]) => ({
		campo,
		entradas: entradas.sort((a, b) => a.forma_clck.localeCompare(b.forma_clck, "es"))
	})).sort((a, b) => a.campo.localeCompare(b.campo, "es"));
}
//#endregion
//#region src/routes/indice/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		const corpus = derived(() => diccionario.estado === "listo" ? {
			version: 1,
			entradas: diccionario.todas(),
			fuentes: [],
			morfemas: []
		} : null);
		const alfabetico = derived(() => corpus() ? construirIndiceAlfabetico(corpus()) : []);
		const semantico = derived(() => corpus() ? agruparPorCampoSemantico(corpus()) : []);
		const porTema = derived(() => page.url.searchParams.get("vista") === "temas");
		const letraActiva = derived(() => page.url.searchParams.get("letra") ?? alfabetico()[0]?.letra ?? "");
		const temaActivo = derived(() => page.url.searchParams.get("tema") ?? semantico()[0]?.campo ?? "");
		const grupoLetra = derived(() => alfabetico().find((g) => g.letra === letraActiva()));
		const grupoTema = derived(() => semantico().find((g) => g.campo === temaActivo()));
		function ir(params) {
			const url = new URL(page.url);
			for (const [clave, valor] of Object.entries(params)) url.searchParams.set(clave, valor);
			goto(url, {
				replaceState: true,
				noScroll: true,
				keepFocus: true
			});
		}
		AppViewLayout($$renderer, {
			titulo: "Índice",
			subtitulo: diccionario.estado === "listo" ? `${diccionario.total} palabras` : void 0,
			children: ($$renderer) => {
				if (diccionario.estado !== "listo") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="estado">Cargando el diccionario…</p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<div class="indice__vistas" role="group" aria-label="Cómo ordenar el índice"><button type="button" class="indice__vista"${attr("aria-pressed", !porTema())}>Alfabético</button> <button type="button" class="indice__vista"${attr("aria-pressed", porTema())}>Por tema</button></div> `);
					if (!porTema()) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<p class="indice__nota">Ordenado por el significado en español, igual que el glosario del Consejo Lingüístico
				Ckunsa. El orden alfabético del ckunsa lo define el Grafemario Unificado, que este proyecto
				todavía no pudo consultar: <code>ck</code>, <code>tch</code> y <code>tt</code> son letras propias y no sabemos en qué posición van. <a href="/grafia">Más sobre la escritura</a>.</p> <nav class="indice__letras" aria-label="Elegir letra"><!--[-->`);
						const each_array = ensure_array_like(alfabetico());
						for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
							let grupo = each_array[$$index];
							const activa = grupo.letra === letraActiva();
							$$renderer.push(`<button type="button" class="indice__letra-boton"${attr("aria-pressed", activa)} translate="no">${escape_html(grupo.letra)}</button>`);
						}
						$$renderer.push(`<!--]--></nav> `);
						if (grupoLetra()) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<h2 class="indice__titulo">${escape_html(grupoLetra().letra)} <small>(${escape_html(grupoLetra().lineas.length)} significados)</small></h2> <ul class="indice__lista"><!--[-->`);
							const each_array_1 = ensure_array_like(grupoLetra().lineas);
							for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
								let linea = each_array_1[$$index_1];
								$$renderer.push(`<li class="indice__linea"><span class="indice__glosa">${escape_html(linea.glosa)}</span> <a class="indice__forma"${attr("href", `/palabra/${stringify(linea.entrada.id)}`)}>`);
								EvidenceBadge($$renderer, {
									nivel: linea.entrada.nivel_evidencia,
									children: ($$renderer) => {
										$$renderer.push(`<!---->${escape_html(linea.entrada.forma_clck)}`);
									},
									$$slots: { default: true }
								});
								$$renderer.push(`<!----></a></li>`);
							}
							$$renderer.push(`<!--]--></ul>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					} else {
						$$renderer.push("<!--[-1-->");
						$$renderer.push(`<p class="indice__nota">Los temas son los 22 capítulos del cuestionario del Intercontinental Dictionary Series,
				adaptados de Buck (1949). No son las categorías del Consejo Lingüístico Ckunsa, que tiene
				las suyas propias.</p> <label class="indice__selector"><span>Tema</span> `);
						$$renderer.select({
							value: temaActivo(),
							onchange: (e) => ir({ tema: e.currentTarget.value })
						}, ($$renderer) => {
							$$renderer.push(`<!--[-->`);
							const each_array_2 = ensure_array_like(semantico());
							for (let $$index_2 = 0, $$length = each_array_2.length; $$index_2 < $$length; $$index_2++) {
								let grupo = each_array_2[$$index_2];
								$$renderer.option({ value: grupo.campo }, ($$renderer) => {
									$$renderer.push(`${escape_html(grupo.campo)} (${escape_html(grupo.entradas.length)})`);
								});
							}
							$$renderer.push(`<!--]-->`);
						});
						$$renderer.push(`</label> `);
						if (grupoTema()) {
							$$renderer.push("<!--[0-->");
							$$renderer.push(`<h2 class="indice__titulo">${escape_html(grupoTema().campo)} <small>(${escape_html(grupoTema().entradas.length)} palabras)</small></h2> <ul class="indice__lista"><!--[-->`);
							const each_array_3 = ensure_array_like(grupoTema().entradas);
							for (let $$index_3 = 0, $$length = each_array_3.length; $$index_3 < $$length; $$index_3++) {
								let entrada = each_array_3[$$index_3];
								$$renderer.push(`<li class="indice__linea"><a class="indice__forma"${attr("href", `/palabra/${stringify(entrada.id)}`)}>`);
								EvidenceBadge($$renderer, {
									nivel: entrada.nivel_evidencia,
									children: ($$renderer) => {
										$$renderer.push(`<!---->${escape_html(entrada.forma_clck)}`);
									},
									$$slots: { default: true }
								});
								$$renderer.push(`<!----></a> <span class="indice__glosa">${escape_html(entrada.significados.join(", "))}</span></li>`);
							}
							$$renderer.push(`<!--]--></ul>`);
						} else $$renderer.push("<!--[-1-->");
						$$renderer.push(`<!--]-->`);
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
