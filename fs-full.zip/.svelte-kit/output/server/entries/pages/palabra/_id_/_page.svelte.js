import "../../../../chunks/index-server.js";
import { b as escape_html, n as derived, r as ensure_array_like, y as attr } from "../../../../chunks/server.js";
import { t as page } from "../../../../chunks/state.js";
import { n as usarDiccionario } from "../../../../chunks/contexto.svelte.js";
import { t as AppViewLayout } from "../../../../chunks/AppViewLayout.js";
import { t as CitaFuente } from "../../../../chunks/CitaFuente.js";
import { n as DESCRIPCION_NIVEL, r as NOTA_GRAFIA_PROVISIONAL, t as EvidenceBadge } from "../../../../chunks/EvidenceBadge.js";
//#region src/lib/componentes/AccionesPalabra.svelte
function AccionesPalabra($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { forma, significado, url } = $$props;
		let aviso = "";
		$$renderer.push(`<div class="acciones"><button class="acciones__boton" type="button">Copiar palabra</button> `);
		$$renderer.push("<!--[-1-->");
		$$renderer.push(`<button class="acciones__boton" type="button">Copiar enlace</button>`);
		$$renderer.push(`<!--]--> <p class="acciones__aviso" role="status" aria-live="polite">${escape_html(aviso)}</p></div>`);
	});
}
//#endregion
//#region src/routes/palabra/[id]/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		const id = derived(() => page.params.id ?? "");
		const entrada = derived(() => diccionario.porId(id()));
		const fuentes = derived(() => (entrada()?.fuentes ?? []).map((f) => diccionario.fuente(f)).filter((f) => f !== void 0));
		const titulo = derived(() => entrada()?.significados[0] ?? "Palabra");
		const cargando = derived(() => diccionario.estado === "cargando" || diccionario.estado === "inicial");
		const volver = derived(() => diccionario.consulta.trim() ? `/?q=${encodeURIComponent(diccionario.consulta)}` : "/");
		AppViewLayout($$renderer, {
			titulo: titulo(),
			children: ($$renderer) => {
				if (cargando()) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="estado">Cargando el diccionario…</p>`);
				} else if (diccionario.estado === "error") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<p class="estado estado--error">No se pudieron cargar los datos. Revisá la conexión y volvé a intentar.</p>`);
				} else if (!entrada()) {
					$$renderer.push("<!--[2-->");
					$$renderer.push(`<p class="estado">No hay ninguna palabra con el identificador «${escape_html(id())}».</p> <p><a${attr("href", volver())}>Volver al buscador</a></p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<article class="palabra"><p class="palabra__forma">`);
					EvidenceBadge($$renderer, {
						nivel: entrada().nivel_evidencia,
						grafiaProvisional: entrada().grafia_provisional,
						children: ($$renderer) => {
							$$renderer.push(`<!---->${escape_html(entrada().forma_clck)}`);
						},
						$$slots: { default: true }
					});
					$$renderer.push(`<!----></p> <p class="palabra__significados">${escape_html(entrada().significados.join(", "))}</p> <dl class="palabra__datos"><dt>Evidencia</dt> <dd>${escape_html(DESCRIPCION_NIVEL[entrada().nivel_evidencia])}</dd> `);
					if (entrada().grafia_provisional) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<dt>Grafía</dt> <dd>${escape_html(NOTA_GRAFIA_PROVISIONAL)}. La grafía unificada la define el Grafemario del Consejo
						Lingüístico Ckunsa, que este proyecto todavía no pudo consultar.</dd>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (entrada().campo_semantico) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<dt>Campo semántico</dt> <dd>${escape_html(entrada().campo_semantico)}</dd>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (entrada().transcripcion_fonologica) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<dt>Transcripción</dt> <dd class="ck-afi">${escape_html(entrada().transcripcion_fonologica)}</dd>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> `);
					if (entrada().observaciones) {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<dt>Nota de la fuente</dt> <dd class="palabra__observaciones">${escape_html(entrada().observaciones)}</dd>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--></dl> `);
					AccionesPalabra($$renderer, {
						forma: entrada().forma_clck,
						significado: entrada().significados.join(", "),
						url: page.url.href
					});
					$$renderer.push(`<!----> `);
					if (entrada().estado === "retirada") {
						$$renderer.push("<!--[0-->");
						$$renderer.push(`<p class="ficha__retirada">Esta forma fue retirada: ${escape_html(entrada().motivo_retiro)}</p>`);
					} else $$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--]--> <section class="palabra__fuentes"><h2 class="palabra__subtitulo">De dónde sale esta palabra</h2> <!--[-->`);
					const each_array = ensure_array_like(fuentes());
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let fuente = each_array[$$index];
						CitaFuente($$renderer, {
							fuente,
							formato: "completa"
						});
					}
					$$renderer.push(`<!--]--></section></article> <p><a${attr("href", volver())}>Volver al buscador</a></p>`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
