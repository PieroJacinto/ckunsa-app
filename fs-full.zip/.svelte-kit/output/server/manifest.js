export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["data/entradas.v1.json","data/fuentes.v1.json","data/manifest.json","data/morfemas.v1.json","favicon.svg","fonts/Andika-Regular-subset.woff2","fonts/caracteres.txt","fonts/OFL.txt","fonts/README.md","icono-192.png","icono-512.png","icono-maskable-512.png","robots.txt","_headers"]),
	mimeTypes: {".json":"application/json",".svg":"image/svg+xml",".woff2":"font/woff2",".txt":"text/plain",".md":"text/markdown",".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.BmT9tMuR.js",app:"_app/immutable/entry/app.DQ4759NL.js",imports:["_app/immutable/entry/start.BmT9tMuR.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/entry/app.DQ4759NL.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/8.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/palabra/[id]",
				pattern: /^\/palabra\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/fuentes/","/grafia/","/indice/","/instalar/","/lengua/","/proyecto/"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
