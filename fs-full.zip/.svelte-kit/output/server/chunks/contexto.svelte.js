import "./index-server.js";
import { d as getContext, n as derived, p as setContext } from "./server.js";
//#region src/lib/domain/normalizacion.ts
/**
* Normalización de grafías ckunsa en dos niveles.
*
* TypeScript puro: sin Svelte, sin DOM. Ver 01-ARQUITECTURA.md §2.
*
* El problema: la misma palabra aparece escrita de cinco formas según la
* fuente (*cunza*, *kunza*, *cunsa*, *kunsa*, *ckunsa*). Pero colapsar todo
* lo que se parece rompe pares mínimos reales del grafemario CLCK:
* `patha` 'gracias' ≠ `patta` 'madre'.
*
* De ahí los dos niveles. Ver 03-MODELO-DE-DATOS.md §3 y
* 02-LINGUISTICA-CKUNSA.md §3.2 (D3).
*/
/**
* Grafemas del ckunsa según `grafemario_ckunsa.csv` del corpus OSF, que es el
* grafemario propuesto por Llanquiman (2023).
*
* OJO: NO es el *Grafemario Unificado Ckunsa* (CLCK, 2018), que sigue sin
* conseguirse (bloqueante B1). Es la mejor aproximación disponible.
*
* Faltan del documento original: reglas de acentuación, tratamiento de
* préstamos y correspondencia grafema→fonema. Ante una duda ortográfica que
* esas reglas resolverían, se marca como pendiente y no se resuelve por
* analogía con el castellano.
*/
var VOCALES = [
	"a",
	"e",
	"i",
	"o",
	"u"
];
/**
* Colapsa las geminadas vocálicas: `aa`→`a`, `ee`→`e`, etc.
*
* Se hace en bucle y no con un único replace porque `aaa` tiene que terminar
* en `a`: un `replace(/aa/g, 'a')` sobre `aaa` deja `aa`.
*/
function colapsarGeminadasVocalicas(s) {
	let resultado = s;
	for (const vocal of VOCALES) {
		const geminada = vocal + vocal;
		while (resultado.includes(geminada)) resultado = resultado.split(geminada).join(vocal);
	}
	return resultado;
}
/**
* Nivel ESTRICTO. Genera la `clave_canonica` que alimenta el índice principal
* de búsqueda.
*
* Sólo hace cuatro cosas: minúsculas, sacar diacríticos, colapsar geminadas
* vocálicas y sacar guiones y espacios.
*
* Deliberadamente NO toca `h`, `th`/`tt`, `ph`/`pp`, `tch`/`tck` ni `y`/`i`:
* en la grafía CLCK son contrastivos y colapsarlos fusiona palabras distintas.
*
* Colapsar geminadas vocálicas sí es seguro: probado contra las 1.727 formas
* del corpus, las 33 colisiones que produce son todas variantes de la misma
* palabra, marcadas por el propio corpus con "Variante: ...".
*
* @param forma  Forma en ckunsa, tal como está en `forma_clck`.
* @returns      Clave de búsqueda estricta.
*/
function canonizar(forma) {
	let s = forma.toLowerCase();
	s = s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").normalize("NFC");
	s = colapsarGeminadasVocalicas(s);
	s = s.replace(/[\s-]/g, "");
	return s;
}
/**
* Equivalencias entre grafías históricas, en ORDEN DE APLICACIÓN.
*
* El orden es crítico: los dígrafos van de más largo a más corto. Si `ck` se
* procesara antes que `tck`, la forma `ckotcko` perdería el dígrafo y daría
* una clave incorrecta. Y las oclusivas simples (`t`, `p`) van DESPUÉS de sus
* dígrafos, para que `hata` y `hatta` terminen en la misma clave.
*
* Los símbolos de destino van en MAYÚSCULA a propósito: como la entrada ya
* pasó por `canonizar()` y está toda en minúscula, las mayúsculas son un
* espacio seguro que ninguna regla posterior vuelve a capturar.
*
* LIMITACIONES CONOCIDAS (documentadas, no accidentales): este nivel NO
* colapsa `b` ~ `p` (*ckapur* ~ *ckabur*) ni la desaparición de la bilabial
* (*ckabur* ~ *caur*). Son alternancias registradas en
* 02-LINGUISTICA-CKUNSA.md §3.3, pero el algoritmo de
* 08-CORPUS-OSF-ANALISIS.md §5 no las cubre y no se inventan acá. Hay tests
* que fijan esta limitación.
*/
var EQUIVALENCIAS_HISTORICAS = [
	[/tck/g, "C"],
	[/tch/g, "C"],
	[/ch/g, "C"],
	[/tz/g, "S"],
	[/ts/g, "S"],
	[/ck/g, "K"],
	[/qu/g, "K"],
	[/ph/g, "P"],
	[/pp/g, "P"],
	[/th/g, "T"],
	[/tt/g, "T"],
	[/[qkc]/g, "K"],
	[/[zç]/g, "s"],
	[/[vwb]/g, "B"],
	[/t/g, "T"],
	[/p/g, "P"],
	[/y/g, "i"],
	[/h/g, ""]
];
/** Colapsa consonantes repetidas: `TT`→`T`, `SS`→`S`. */
function colapsarRepetidas(s) {
	return s.replace(/(.)\1+/g, "$1");
}
/**
* Nivel TOLERANTE. Genera la `clave_historica`.
*
* SÓLO SE CONSULTA COMO FALLBACK, cuando el nivel estricto no devolvió nada.
* Es deliberadamente lossy: fusiona pares mínimos que `canonizar()` mantiene
* separados. Consultarlo primero rompería el diccionario.
*
* Existe para un caso concreto y real: quien aprendió con material de los 80
* escribe *kunza* y tiene que encontrar *ckunsa*.
*
* Todo resultado que salga por este camino se marca `motivo: 'aproximada'` y
* la UI explica la coincidencia. Es didáctico, no ruido.
*
* @param forma  Forma en ckunsa o en cualquier grafía histórica.
* @returns      Clave de búsqueda tolerante.
*/
function historizar(forma) {
	let s = canonizar(forma);
	for (const [patron, reemplazo] of EQUIVALENCIAS_HISTORICAS) s = s.replace(patron, reemplazo);
	s = s.replace(/a[ou]$/, "u");
	s = colapsarRepetidas(s);
	return s;
}
//#endregion
//#region src/lib/domain/busqueda.ts
/**
* Índice de búsqueda en memoria y ranking.
*
* TypeScript puro: sin Svelte, sin DOM (`01-ARQUITECTURA` §2). Sin librerías:
* medido sobre el corpus real, el fuzzy cuesta 0,17 ms por consulta con 851
* entradas y 0,61 ms con 5.000. Un frame a 60 fps son 16,7 ms, así que estamos
* dos órdenes de magnitud por debajo de lo perceptible. Por eso no se instaló
* ninguna librería de fuzzy search (`01-ARQUITECTURA` §9).
*
* Ranking y motivos: `03-MODELO-DE-DATOS.md` §4.
*
* NOTA: no usar parameter properties (`constructor(private x)`), enums ni
* namespaces. No son sintaxis borrable y rompen la ejecución directa con Node
* (`ERR_UNSUPPORTED_TYPESCRIPT_SYNTAX`), que es como corre el pipeline.
*/
/**
* Cómo se le explica al usuario por qué apareció un resultado.
*
* `null` cuando no hace falta explicar nada: si buscó `ckabur` y encontró
* `ckabur`, decirle "coincidencia exacta" es ruido. Sólo se anuncian las
* coincidencias que el usuario no esperaba, que es lo didáctico
* (`07-DISENO` V5.4).
*/
var DESCRIPCION_MOTIVO = {
	exacta: null,
	variante: "coincide con una variante registrada de esta palabra",
	espanol: null,
	prefijo: null,
	contiene: null,
	aproximada: "coincidencia aproximada"
};
/** Consultas más cortas no entran al fuzzy ni a "contiene": devolverían todo. */
var MINIMO_PARA_PARCIAL = 3;
function agregar(mapa, clave, id) {
	if (!clave) return;
	const ids = mapa.get(clave);
	if (ids) {
		if (!ids.includes(id)) ids.push(id);
	} else mapa.set(clave, [id]);
}
/** Minúsculas y sin acentos. Para el lado español, que no usa grafía ckunsa. */
function normalizarSignificado(texto) {
	return texto.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").normalize("NFC").trim();
}
/**
* Arma el índice. Se llama una vez al cargar el corpus: medido, 3,9 ms con 851
* entradas y 13,5 ms con 2.500.
*
* Las entradas retiradas SÍ entran al índice, porque `buscarExacta` tiene que
* poder encontrarlas para mostrar el motivo del retiro. Es `buscar` la que las
* filtra de los resultados normales (`03-MODELO-DE-DATOS` §5).
*/
function construirIndice(corpus) {
	const indice = {
		porId: /* @__PURE__ */ new Map(),
		porCanonica: /* @__PURE__ */ new Map(),
		porHistorica: /* @__PURE__ */ new Map(),
		porVariante: /* @__PURE__ */ new Map(),
		porSignificado: /* @__PURE__ */ new Map(),
		canonicas: [],
		significados: []
	};
	for (const entrada of corpus.entradas) {
		indice.porId.set(entrada.id, entrada);
		agregar(indice.porCanonica, entrada.clave_canonica, entrada.id);
		agregar(indice.porHistorica, entrada.clave_historica, entrada.id);
		for (const variante of entrada.variantes_historicas ?? []) {
			agregar(indice.porVariante, canonizar(variante.forma), entrada.id);
			agregar(indice.porHistorica, historizar(variante.forma), entrada.id);
		}
		for (const significado of entrada.significados) agregar(indice.porSignificado, normalizarSignificado(significado), entrada.id);
	}
	indice.canonicas = [...indice.porCanonica.keys()];
	indice.significados = [...indice.porSignificado.keys()];
	return indice;
}
/**
* Distancia de Levenshtein ACOTADA, con dos salidas tempranas.
*
* Sin el corte, el 95% del trabajo se gasta comparando contra palabras que no
* se parecen en nada. Devuelve `max + 1` para decir "se pasó", sin calcular el
* valor real.
*/
function distancia(a, b, max) {
	if (Math.abs(a.length - b.length) > max) return max + 1;
	let previa = new Array(b.length + 1);
	let actual = new Array(b.length + 1);
	for (let j = 0; j <= b.length; j++) previa[j] = j;
	for (let i = 1; i <= a.length; i++) {
		actual[0] = i;
		let mejor = i;
		for (let j = 1; j <= b.length; j++) {
			const costo = a[i - 1] === b[j - 1] ? 0 : 1;
			const valor = Math.min(actual[j - 1] + 1, previa[j] + 1, previa[j - 1] + costo);
			actual[j] = valor;
			if (valor < mejor) mejor = valor;
		}
		if (mejor > max) return max + 1;
		const tmp = previa;
		previa = actual;
		actual = tmp;
	}
	return previa[b.length];
}
/**
* Junta resultados en orden de ranking, sin repetir entradas: la primera razón
* por la que apareció es la que se muestra, y es la más fuerte.
*/
function crearAcumulador(indice) {
	const vistos = /* @__PURE__ */ new Set();
	const resultados = [];
	const lleno = () => resultados.length >= 50;
	return {
		resultados,
		lleno,
		sumar(ids, motivo, detalle) {
			if (!ids) return;
			for (const id of ids) {
				if (lleno()) return;
				if (vistos.has(id)) continue;
				const entrada = indice.porId.get(id);
				if (!entrada) continue;
				if (entrada.estado === "retirada") continue;
				vistos.add(id);
				resultados.push(detalle === void 0 ? {
					entrada,
					motivo
				} : {
					entrada,
					motivo,
					detalle
				});
			}
		}
	};
}
/**
* Busca en las dos direcciones a la vez: español → ckunsa y ckunsa → español,
* con el mismo input y sin selector de idioma. Alguien que escribe "cueva"
* obtiene `toco` y `ckoiba`; alguien que escribe "toco" obtiene su ficha.
*
* Orden de ranking (`03-MODELO-DE-DATOS` §4): exacta canónica, variante
* declarada, significado exacto, prefijos, contiene, grafía histórica y fuzzy.
* Los dos últimos salen marcados `aproximada` con su explicación.
*/
function buscar(indice, consulta) {
	const bruta = consulta.trim();
	if (bruta === "") return [];
	const ck = canonizar(bruta);
	const es = normalizarSignificado(bruta);
	const acc = crearAcumulador(indice);
	acc.sumar(indice.porCanonica.get(ck), "exacta");
	acc.sumar(indice.porVariante.get(ck), "variante");
	acc.sumar(indice.porSignificado.get(es), "espanol");
	if (!acc.lleno()) for (const clave of indice.canonicas) {
		if (acc.lleno()) break;
		if (clave !== ck && clave.startsWith(ck)) acc.sumar(indice.porCanonica.get(clave), "prefijo");
	}
	if (!acc.lleno()) for (const significado of indice.significados) {
		if (acc.lleno()) break;
		if (significado !== es && significado.startsWith(es)) acc.sumar(indice.porSignificado.get(significado), "prefijo");
	}
	if (!acc.lleno() && ck.length >= MINIMO_PARA_PARCIAL) {
		for (const clave of indice.canonicas) {
			if (acc.lleno()) break;
			if (clave.includes(ck)) acc.sumar(indice.porCanonica.get(clave), "contiene");
		}
		for (const significado of indice.significados) {
			if (acc.lleno()) break;
			if (significado.includes(es)) acc.sumar(indice.porSignificado.get(significado), "contiene");
		}
	}
	if (!acc.lleno()) acc.sumar(indice.porHistorica.get(historizar(bruta)), "aproximada", `coincide con la grafía histórica de "${bruta}"`);
	if (!acc.lleno() && ck.length >= MINIMO_PARA_PARCIAL) {
		const max = ck.length <= 6 ? 1 : 2;
		for (const clave of indice.canonicas) {
			if (acc.lleno()) break;
			if (distancia(ck, clave, max) <= max) acc.sumar(indice.porCanonica.get(clave), "aproximada", `parecido a "${clave}"`);
		}
	}
	return acc.resultados;
}
/**
* Búsqueda exacta que SÍ devuelve las entradas retiradas.
*
* Es la que usa la ficha de palabra: quien busca una forma retirada tiene que
* encontrar la explicación de por qué se retiró, no una pantalla vacía
* (`03-MODELO-DE-DATOS` §5).
*/
function buscarExacta(indice, consulta) {
	const ck = canonizar(consulta.trim());
	if (!ck) return [];
	const ids = /* @__PURE__ */ new Set([...indice.porCanonica.get(ck) ?? [], ...indice.porVariante.get(ck) ?? []]);
	const entradas = [];
	for (const id of ids) {
		const entrada = indice.porId.get(id);
		if (entrada) entradas.push(entrada);
	}
	return entradas;
}
//#endregion
//#region src/lib/datos/cargador.ts
/** Error con la URL adentro: sin eso, "failed to fetch" no dice nada. */
var ErrorDeCarga = class extends Error {
	url;
	constructor(url, motivo) {
		super(`No se pudieron cargar los datos desde ${url}: ${motivo}`);
		this.name = "ErrorDeCarga";
		this.url = url;
	}
};
var BASE_POR_DEFECTO = "/data";
function url(base, archivo) {
	return `${base.replace(/\/$/, "")}/${archivo}`;
}
async function traerJson(opciones, archivo, sinCache) {
	const destino = url(opciones.base ?? BASE_POR_DEFECTO, archivo);
	let respuesta;
	try {
		respuesta = await opciones.fetch(destino, sinCache ? { cache: "no-cache" } : void 0);
	} catch (causa) {
		throw new ErrorDeCarga(destino, causa instanceof Error ? causa.message : "sin conexión");
	}
	if (!respuesta.ok) throw new ErrorDeCarga(destino, `respuesta ${respuesta.status}`);
	try {
		return await respuesta.json();
	} catch {
		throw new ErrorDeCarga(destino, "la respuesta no es JSON válido");
	}
}
/** Chequeo de forma mínimo. La validación completa es del build, no del cliente. */
function esManifest(valor) {
	if (typeof valor !== "object" || valor === null) return false;
	const m = valor;
	return typeof m.version === "number" && typeof m.archivos === "object" && m.archivos !== null && typeof m.archivos.entradas === "string" && typeof m.archivos.fuentes === "string" && typeof m.archivos.morfemas === "string";
}
/**
* Trae el manifest SIN caché. Es el único pedido que salta la caché: es lo que
* permite que subir un JSON nuevo y bumpear la versión llegue al usuario sin
* redeployar la app (`01-ARQUITECTURA` §7).
*/
async function cargarManifest(opciones) {
	const crudo = await traerJson(opciones, "manifest.json", true);
	if (!esManifest(crudo)) throw new ErrorDeCarga(url(opciones.base ?? BASE_POR_DEFECTO, "manifest.json"), "formato inesperado");
	return crudo;
}
/**
* Trae el corpus completo. Los tres archivos van en paralelo: son independientes
* y encadenarlos triplicaría la espera en una conexión lenta.
*
* @param manifest  Si ya lo tenés, pasalo y se evita el pedido extra.
*/
async function cargarCorpus(opciones, manifest) {
	const m = manifest ?? await cargarManifest(opciones);
	const [entradas, fuentes, morfemas] = await Promise.all([
		traerJson(opciones, m.archivos.entradas, false),
		traerJson(opciones, m.archivos.fuentes, false),
		traerJson(opciones, m.archivos.morfemas, false)
	]);
	if (!Array.isArray(entradas) || !Array.isArray(fuentes) || !Array.isArray(morfemas)) throw new ErrorDeCarga(opciones.base ?? BASE_POR_DEFECTO, "los archivos de datos no son listas");
	return {
		version: m.version,
		entradas,
		fuentes,
		morfemas
	};
}
/**
* ¿El manifest del servidor es más nuevo que lo que la app tiene cargado?
*
* Sólo compara. Nunca recarga sola: mostrar el aviso y esperar que el usuario
* decida es deliberado, porque recargar de prepo mientras alguien está leyendo
* una ficha es hostil (`01-ARQUITECTURA` §7).
*/
function hayVersionNueva(manifest, versionCargada) {
	return versionCargada !== null && manifest.version > versionCargada;
}
//#endregion
//#region src/lib/stores/diccionario.svelte.ts
function crearDiccionario() {
	let estado = "inicial";
	let error = null;
	let consulta = "";
	let corpus = null;
	let indice = null;
	let manifestNuevo = null;
	const resultados = derived(() => indice && consulta.trim() ? buscar(indice, consulta) : []);
	const versionCargada = derived(() => corpus?.version ?? null);
	const hayActualizacion = derived(() => manifestNuevo !== null && hayVersionNueva(manifestNuevo, corpus?.version ?? null));
	return {
		get estado() {
			return estado;
		},
		get error() {
			return error;
		},
		get consulta() {
			return consulta;
		},
		get resultados() {
			return resultados();
		},
		get total() {
			return corpus?.entradas.length ?? 0;
		},
		get versionCargada() {
			return versionCargada();
		},
		get hayActualizacion() {
			return hayActualizacion();
		},
		async cargar(opciones) {
			if (estado === "cargando") return;
			estado = "cargando";
			error = null;
			try {
				const cargado = await cargarCorpus(opciones);
				corpus = cargado;
				indice = construirIndice(cargado);
				estado = "listo";
			} catch (causa) {
				error = causa instanceof Error ? causa.message : "error desconocido";
				estado = "error";
			}
		},
		/**
		* Consulta el manifest y expone el flag. NUNCA recarga sola: recargar de
		* prepo mientras alguien lee una ficha es hostil (`01-ARQUITECTURA` §7).
		*/
		async revisarActualizacion(opciones) {
			try {
				manifestNuevo = await cargarManifest(opciones);
			} catch {}
		},
		/**
		* A diferencia de `cargar`, si esto falla NO rompe nada: el corpus que ya
		* está en memoria sigue sirviendo. Aplicar una actualización sin señal no
		* puede dejar al usuario sin diccionario.
		*/
		async aplicarActualizacion(opciones) {
			if (estado === "cargando") return;
			const estadoPrevio = estado;
			estado = "cargando";
			try {
				const cargado = await cargarCorpus(opciones);
				corpus = cargado;
				indice = construirIndice(cargado);
				manifestNuevo = null;
				estado = "listo";
			} catch {
				estado = estadoPrevio;
			}
		},
		buscar(nueva) {
			consulta = nueva;
		},
		porId(id) {
			return indice?.porId.get(id);
		},
		todas() {
			return corpus?.entradas ?? [];
		},
		fichaDe(forma) {
			return indice ? buscarExacta(indice, forma) : [];
		},
		fuente(id) {
			return corpus?.fuentes.find((f) => f.id === id);
		},
		fuentes() {
			return corpus?.fuentes ?? [];
		}
	};
}
//#endregion
//#region src/lib/stores/contexto.svelte.ts
var CLAVE = Symbol("diccionario");
function proveerDiccionario(instancia = crearDiccionario()) {
	setContext(CLAVE, instancia);
	return instancia;
}
/**
* Lo pide cualquier componente del árbol.
*
* Falla ruidosamente si no hay ninguno: un `undefined` silencioso se
* manifestaría mucho después como una pantalla vacía sin explicación.
*/
function usarDiccionario() {
	const instancia = getContext(CLAVE);
	if (!instancia) throw new Error("No hay diccionario en el contexto. Falta llamar a proveerDiccionario() en +layout.svelte.");
	return instancia;
}
//#endregion
export { normalizarSignificado as i, usarDiccionario as n, DESCRIPCION_MOTIVO as r, proveerDiccionario as t };
