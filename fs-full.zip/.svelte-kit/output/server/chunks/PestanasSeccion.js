import { b as escape_html, r as ensure_array_like, y as attr } from "./server.js";
//#region src/lib/componentes/PestanasSeccion.svelte
function PestanasSeccion($$renderer, $$props) {
	/** `page.url.pathname`, provisto por la página. */
	/** Etiqueta accesible: distingue esta navegación de la principal. */
	let { pestanas, rutaActual, etiqueta } = $$props;
	function normalizar(ruta) {
		return ruta !== "/" && ruta.endsWith("/") ? ruta.slice(0, -1) : ruta;
	}
	$$renderer.push(`<nav class="pestanas"${attr("aria-label", etiqueta)}><!--[-->`);
	const each_array = ensure_array_like(pestanas);
	for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
		let pestana = each_array[$$index];
		const actual = normalizar(rutaActual) === pestana.href ? "page" : void 0;
		$$renderer.push(`<a class="pestanas__enlace"${attr("href", pestana.href)}${attr("aria-current", actual)}>${escape_html(pestana.texto)}</a>`);
	}
	$$renderer.push(`<!--]--></nav>`);
}
//#endregion
export { PestanasSeccion as t };
