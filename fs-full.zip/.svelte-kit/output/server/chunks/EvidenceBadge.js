import { b as escape_html, n as derived, o as stringify, t as attr_class, y as attr } from "./server.js";
//#region src/lib/domain/evidencia.ts
/** Nombre visible del nivel. Va escrito en el badge, no sólo el color. */
var ETIQUETA_NIVEL = {
	atestiguada: "atestiguada",
	unificada: "unificada",
	reconstruida: "reconstruida",
	propuesta: "propuesta"
};
/**
* Explicación en una línea, en lenguaje llano.
*
* El destinatario es un chico de escuela o un docente, no un lingüista: dice
* qué respaldo tiene la forma, sin jerga.
*/
var DESCRIPCION_NIVEL = {
	atestiguada: "Aparece tal cual en una fuente documental.",
	unificada: "Forma del Diccionario Unificado del Consejo Lingüístico Ckunsa.",
	reconstruida: "No está documentada así: sale de un análisis o de aplicar una regla.",
	propuesta: "La propuso la comunidad o un educador. No tiene respaldo documental."
};
var ICONO_NIVEL = {
	atestiguada: "libro",
	unificada: "tilde",
	reconstruida: "herramienta",
	propuesta: "comunidad"
};
/** Nota de la segunda marca: la grafía, que es un eje distinto (`03` §2.4). */
var NOTA_GRAFIA_PROVISIONAL = "grafía de la fuente, pendiente de normalización";
//#endregion
//#region src/lib/componentes/EvidenceBadge.svelte
function EvidenceBadge($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Segunda marca, eje distinto: la ortografía (`03` §2.4). */
		/**
		* La forma en ckunsa. Va como snippet: el badge envuelve, no recibe texto.
		*
		* Opcional para poder usar el badge suelto en una leyenda, donde se
		* explica qué significa cada marca y no hay ninguna forma que mostrar.
		* La regla 1 dice que toda forma pasa por el badge, no que el badge
		* siempre lleve una forma.
		*/
		let { nivel, grafiaProvisional = false, children } = $$props;
		const etiqueta = derived(() => ETIQUETA_NIVEL[nivel]);
		const descripcion = derived(() => DESCRIPCION_NIVEL[nivel]);
		const icono = derived(() => ICONO_NIVEL[nivel]);
		$$renderer.push(`<span class="evidencia"${attr("data-nivel", nivel)}>`);
		if (children) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="evidencia__forma" translate="no" lang="kuz">`);
			children($$renderer);
			$$renderer.push(`<!----></span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> <span${attr_class(`evidencia__marca evidencia__marca--${stringify(nivel)}`)}${attr("title", descripcion())}><svg class="evidencia__icono" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">`);
		if (icono() === "libro") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<path d="M2.5 3h4a2 2 0 0 1 2 2v8a1.5 1.5 0 0 0-1.5-1.5h-4.5z"></path><path d="M13.5 3h-4a2 2 0 0 0-2 2v8a1.5 1.5 0 0 1 1.5-1.5h4.5z"></path>`);
		} else if (icono() === "tilde") {
			$$renderer.push("<!--[1-->");
			$$renderer.push(`<path d="M3 8.5 6.5 12 13 4.5"></path>`);
		} else if (icono() === "herramienta") {
			$$renderer.push("<!--[2-->");
			$$renderer.push(`<path d="M10.5 2.5a3.5 3.5 0 0 0-4.4 4.4L2.5 10.5v3h3l3.6-3.6a3.5 3.5 0 0 0 4.4-4.4l-2 2-1.9-.5-.5-1.9z"></path>`);
		} else if (icono() === "comunidad") {
			$$renderer.push("<!--[3-->");
			$$renderer.push(`<circle cx="5.5" cy="5.5" r="2"></circle><circle cx="11" cy="6.5" r="1.6"></circle><path d="M1.5 13c0-2.2 1.8-3.5 4-3.5s4 1.3 4 3.5"></path><path d="M11 9.5c2 0 3.5 1.1 3.5 3"></path>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></svg> <span class="evidencia__texto">${escape_html(etiqueta())}</span></span> `);
		if (grafiaProvisional) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<span class="evidencia__grafia">${escape_html(NOTA_GRAFIA_PROVISIONAL)}</span>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></span>`);
	});
}
//#endregion
export { DESCRIPCION_NIVEL as n, NOTA_GRAFIA_PROVISIONAL as r, EvidenceBadge as t };
