import { b as escape_html, o as stringify, y as attr } from "./server.js";
//#region src/lib/componentes/CitaFuente.svelte
function CitaFuente($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { fuente, formato = "completa" } = $$props;
		if (formato === "compacta") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a class="cita cita--compacta"${attr("href", `/fuentes#${stringify(fuente.id)}`)}>${escape_html(fuente.cita_corta)}</a>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="cita cita--completa"${attr("id", fuente.id)}><p class="cita__texto">${escape_html(fuente.cita)}</p> <p class="cita__licencia">Licencia: ${escape_html(fuente.licencia)} `);
			if (fuente.url) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`· <a${attr("href", fuente.url)} rel="noreferrer">${escape_html(fuente.url)}</a>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></p></div>`);
		}
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
export { CitaFuente as t };
