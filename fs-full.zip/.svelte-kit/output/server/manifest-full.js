export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["data/entradas.v1.json","data/fuentes.v1.json","data/manifest.json","data/morfemas.v1.json","favicon.svg","fonts/Andika-Regular-subset.woff2","fonts/caracteres.txt","fonts/OFL.txt","fonts/README.md","icono-192.png","icono-512.png","icono-maskable-512.png","robots.txt","_headers"]),
	mimeTypes: {".json":"application/json",".svg":"image/svg+xml",".woff2":"font/woff2",".txt":"text/plain",".md":"text/markdown",".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.BmT9tMuR.js",app:"_app/immutable/entry/app.DQ4759NL.js",imports:["_app/immutable/entry/start.BmT9tMuR.js","_app/immutable/chunks/Bi39FpoZ.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/entry/app.DQ4759NL.js","_app/immutable/chunks/DYLrXJ3l.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js')),
			__memo(() => import('./nodes/9.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/fuentes",
				pattern: /^\/fuentes\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/grafia",
				pattern: /^\/grafia\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/indice",
				pattern: /^\/indice\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/instalar",
				pattern: /^\/instalar\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/lengua",
				pattern: /^\/lengua\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/palabra/[id]",
				pattern: /^\/palabra\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/proyecto",
				pattern: /^\/proyecto\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
