

export const index = 1;
export const imports = ["_app/immutable/nodes/1.D_tZlWBF.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Ni9b1ejd.js","_app/immutable/chunks/CBQKDko8.js"];
export const stylesheets = [];
export const fonts = [];
