

export const index = 4;
export const universal = {
  "ssr": false,
  "prerender": false,
  "trailingSlash": "always"
};
export const universal_id = "src/routes/palabra/[id]/+page.ts";
export const imports = ["_app/immutable/nodes/4.DeBItIfG.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Ni9b1ejd.js","_app/immutable/chunks/CBQKDko8.js","_app/immutable/chunks/B85lC-kq.js","_app/immutable/chunks/Bd1Ify34.js","_app/immutable/chunks/BpiXv7Qi.js"];
export const stylesheets = [];
export const fonts = [];
