

export const index = 0;
export const universal = {
  "ssr": false,
  "prerender": true,
  "trailingSlash": "always"
};
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.D7aoDKPD.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/Ni9b1ejd.js","_app/immutable/chunks/CBQKDko8.js","_app/immutable/chunks/B85lC-kq.js"];
export const stylesheets = ["_app/immutable/assets/0.us2_7OAB.css"];
export const fonts = [];
