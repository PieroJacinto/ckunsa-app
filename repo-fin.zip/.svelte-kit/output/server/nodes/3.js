

export const index = 3;
export const imports = ["_app/immutable/nodes/3.DwlU_-ls.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/B85lC-kq.js","_app/immutable/chunks/Bd1Ify34.js"];
export const stylesheets = [];
export const fonts = [];
