

export const index = 2;
export const imports = ["_app/immutable/nodes/2.DGfW3w80.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/B85lC-kq.js","_app/immutable/chunks/Bd1Ify34.js","_app/immutable/chunks/BpiXv7Qi.js"];
export const stylesheets = [];
export const fonts = [];
