import { a as ensure_array_like, i as derived } from "../../../chunks/index-server.js";
import { n as usarDiccionario } from "../../../chunks/contexto.svelte.js";
import { n as AppViewLayout, t as CitaFuente } from "../../../chunks/CitaFuente.js";
//#region src/routes/fuentes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		const todas = derived(() => diccionario.fuentes());
		const documentales = derived(() => todas().filter((f) => f.tipo !== "catalogo"));
		const catalogos = derived(() => todas().filter((f) => f.tipo === "catalogo"));
		AppViewLayout($$renderer, {
			titulo: "Fuentes y créditos",
			children: ($$renderer) => {
				$$renderer.push(`<p class="fuentes__patrimonio">El ckunsa es patrimonio del pueblo <strong>lickanantay</strong>. Esta aplicación reúne material
		publicado sobre la lengua; no la reemplaza ni la representa.</p> <section class="fuentes__seccion"><h2>Organizaciones del territorio</h2> <p>La autoridad sobre la lengua es de las organizaciones lickanantay. Estas son las instituciones
			a las que corresponde consultar sobre el ckunsa. <strong>Este proyecto todavía no cuenta con su aval</strong>: figuran acá como referencia, no como colaboradoras.</p> <ul><li><strong>Consejo Lingüístico Ckunsa (CLCK)</strong> — fundado el 14 de diciembre de 2010.
				Publicó el <em>Grafemario Unificado Ckunsa</em> (2018) y el <em>Diccionario Unificado Ckunsa</em> (2021), que definen la grafía oficial.</li> <li><strong>CONADI El Loa</strong></li> <li><strong>Fundación Yockontur</strong> — trabajo de revitalización en San Pedro.</li> <li><strong>Centro de Pensamiento Atacameño Ckunsa Ttulva</strong></li> <li><strong>Educadores tradicionales</strong> de las escuelas de San Pedro de Atacama, Toconao, Peine,
				Socaire, Caspana y Chiu Chiu.</li></ul></section> <section class="fuentes__seccion"><h2>Fuentes de los datos</h2> `);
				if (diccionario.estado !== "listo") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="estado">Cargando…</p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<!--[-->`);
					const each_array = ensure_array_like(documentales());
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let fuente = each_array[$$index];
						$$renderer.push(`<div class="fuentes__item">`);
						CitaFuente($$renderer, {
							fuente,
							formato: "completa"
						});
						$$renderer.push(`<!----></div>`);
					}
					$$renderer.push(`<!--]-->`);
				}
				$$renderer.push(`<!--]--></section> `);
				if (catalogos().length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<section class="fuentes__seccion"><h2>Catálogos de referencia</h2> <p>No documentan el ckunsa: son infraestructura. Aportan la lista de conceptos y sus glosas en
				español.</p> <!--[-->`);
					const each_array_1 = ensure_array_like(catalogos());
					for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
						let fuente = each_array_1[$$index_1];
						$$renderer.push(`<div class="fuentes__item">`);
						CitaFuente($$renderer, {
							fuente,
							formato: "completa"
						});
						$$renderer.push(`<!----></div>`);
					}
					$$renderer.push(`<!--]--></section>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> <section class="fuentes__seccion"><h2>Qué falta</h2> <p>Las formas que muestra la aplicación están escritas en la grafía de sus fuentes, no en la
			grafía unificada del CLCK. Para normalizarlas hace falta el <em>Grafemario Unificado Ckunsa</em> (2018), que este proyecto todavía no pudo consultar.</p> <p>Tampoco están incorporados el <em>Diccionario Unificado Ckunsa</em> (2021) ni el corpus morfofonológico
			de Llanquiman, Hasler y Torrico-Ávila, cuyo uso requiere autorización.</p></section> <section class="fuentes__seccion"><h2>Tipografía</h2> <p>Andika, de SIL Global, bajo <abbr title="SIL Open Font License">OFL</abbr> 1.1. Diseñada para materiales
			de alfabetización y con soporte de alfabeto fonético internacional.</p></section> <section class="fuentes__seccion fuentes__seccion--desarrollo"><h2>Desarrollo</h2> <p>Piero Jacinto — <a href="https://github.com/PieroJacinto" rel="noreferrer">github.com/PieroJacinto</a></p> <p>Desarrollo independiente, sin fines de lucro. El código es abierto y las decisiones —incluido
			el algoritmo de búsqueda y qué se muestra de cada palabra— están documentadas y pueden
			auditarse.</p> <p>Si alguna organización lickanantay considera que algo de esta aplicación no corresponde
			publicarse, se retira sin condiciones.</p></section>`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
