import { a as ensure_array_like, c as stringify, d as attr, f as escape_html, i as derived } from "../../chunks/index-server.js";
import { n as usarDiccionario, r as DESCRIPCION_MOTIVO } from "../../chunks/contexto.svelte.js";
import { n as AppViewLayout, t as CitaFuente } from "../../chunks/CitaFuente.js";
import { t as EvidenceBadge } from "../../chunks/EvidenceBadge.js";
//#region src/lib/componentes/BuscadorInput.svelte
function BuscadorInput($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Para el anuncio a lectores de pantalla. */
		let { valor, onBuscar, cantidadResultados, placeholder = "ckabur, montaña, agua…" } = $$props;
		const anuncio = derived(() => {
			if (valor.trim() === "" || cantidadResultados === void 0) return "";
			if (cantidadResultados === 0) return "Sin resultados";
			if (cantidadResultados === 1) return "1 resultado";
			return `${cantidadResultados} resultados`;
		});
		$$renderer.push(`<div class="buscador"><label class="buscador__etiqueta visualmente-oculto" for="buscador-consulta">Buscar en ckunsa o en español</label> <div class="buscador__campo"><svg class="buscador__lupa" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><circle cx="7" cy="7" r="4.5"></circle><path d="M10.5 10.5 14 14"></path></svg> <input id="buscador-consulta" class="buscador__input" type="search" autocomplete="off" spellcheck="false"${attr("placeholder", placeholder)}${attr("value", valor)}/> `);
		if (valor !== "") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<button class="buscador__limpiar" type="button" title="Limpiar la búsqueda"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"></path></svg> <span class="visualmente-oculto">Limpiar la búsqueda</span></button>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></div> <p class="buscador__anuncio visualmente-oculto" role="status" aria-live="polite">${escape_html(anuncio())}</p></div>`);
	});
}
//#endregion
//#region src/lib/componentes/EntradaCard.svelte
function EntradaCard($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		/** Si viene, se cita en formato compacto. */
		/** Explicación puntual del buscador, más precisa que la genérica. */
		/**
		* Mostrar la nota de grafía provisional en esta tarjeta.
		*
		* Por defecto NO, porque en un listado la llevan las 851 entradas y una
		* advertencia que aparece en todos los ítems deja de informar (V4.1). El
		* listado la dice una vez arriba; la ficha de palabra la pasa en `true`.
		*/
		let { entrada, fuente, motivo, detalle, mostrarNotaGrafia = false } = $$props;
		const aviso = derived(() => motivo ? DESCRIPCION_MOTIVO[motivo] : null);
		$$renderer.push(`<article class="ficha"><h2 class="ficha__titulo"><a class="ficha__enlace"${attr("href", `/palabra/${stringify(entrada.id)}`)}>`);
		EvidenceBadge($$renderer, {
			nivel: entrada.nivel_evidencia,
			grafiaProvisional: mostrarNotaGrafia && entrada.grafia_provisional,
			children: ($$renderer) => {
				$$renderer.push(`<!---->${escape_html(entrada.forma_clck)}`);
			},
			$$slots: { default: true }
		});
		$$renderer.push(`<!----></a></h2> <p class="ficha__significados">${escape_html(entrada.significados.join(", "))}</p> `);
		if (entrada.campo_semantico) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__campo">${escape_html(entrada.campo_semantico)}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (aviso()) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__coincidencia">${escape_html(detalle ?? aviso())}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (entrada.estado === "retirada") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__retirada">Esta forma fue retirada: ${escape_html(entrada.motivo_retiro)}</p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--> `);
		if (fuente) {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<p class="ficha__fuente">`);
			CitaFuente($$renderer, {
				fuente,
				formato: "compacta"
			});
			$$renderer.push(`<!----></p>`);
		} else $$renderer.push("<!--[-1-->");
		$$renderer.push(`<!--]--></article>`);
	});
}
//#endregion
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		const diccionario = usarDiccionario();
		const subtitulo = derived(() => diccionario.estado === "listo" ? `${diccionario.total} palabras` : void 0);
		AppViewLayout($$renderer, {
			titulo: "Diccionario ckunsa",
			subtitulo: subtitulo(),
			children: ($$renderer) => {
				BuscadorInput($$renderer, {
					valor: diccionario.consulta,
					onBuscar: (q) => diccionario.buscar(q),
					cantidadResultados: diccionario.estado === "listo" ? diccionario.resultados.length : void 0
				});
				$$renderer.push(`<!----> `);
				if (diccionario.estado === "listo" && diccionario.resultados.length > 0) {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="aviso-grafia">Las formas están escritas en la grafía de sus fuentes. La normalización a la grafía unificada
			del Consejo Lingüístico Ckunsa está pendiente.</p>`);
				} else $$renderer.push("<!--[-1-->");
				$$renderer.push(`<!--]--> `);
				if (diccionario.estado === "cargando" || diccionario.estado === "inicial") {
					$$renderer.push("<!--[0-->");
					$$renderer.push(`<p class="estado">Cargando el diccionario…</p>`);
				} else if (diccionario.estado === "error") {
					$$renderer.push("<!--[1-->");
					$$renderer.push(`<p class="estado estado--error">No se pudieron cargar los datos. Revisá la conexión y volvé a intentar.</p>`);
				} else if (diccionario.consulta.trim() === "") {
					$$renderer.push("<!--[2-->");
					$$renderer.push(`<p class="estado">Escribí una palabra en ckunsa o en español. La búsqueda funciona en las dos direcciones.</p>`);
				} else if (diccionario.resultados.length === 0) {
					$$renderer.push("<!--[3-->");
					$$renderer.push(`<p class="estado">No se encontró nada para «${escape_html(diccionario.consulta)}».</p>`);
				} else {
					$$renderer.push("<!--[-1-->");
					$$renderer.push(`<ul class="resultados"><!--[-->`);
					const each_array = ensure_array_like(diccionario.resultados);
					for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
						let resultado = each_array[$$index];
						$$renderer.push(`<li>`);
						EntradaCard($$renderer, {
							entrada: resultado.entrada,
							fuente: diccionario.fuente(resultado.entrada.fuentes[0] ?? ""),
							motivo: resultado.motivo,
							detalle: resultado.detalle
						});
						$$renderer.push(`<!----></li>`);
					}
					$$renderer.push(`<!--]--></ul>`);
				}
				$$renderer.push(`<!--]-->`);
			},
			$$slots: { default: true }
		});
	});
}
//#endregion
export { _page as default };
