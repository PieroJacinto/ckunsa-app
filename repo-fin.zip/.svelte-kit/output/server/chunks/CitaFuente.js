import { c as stringify, d as attr, f as escape_html, o as head } from "./index-server.js";
//#region src/lib/componentes/AppViewLayout.svelte
function AppViewLayout($$renderer, $$props) {
	/** Contenido opcional del encabezado, a la derecha del título. */
	let { titulo, subtitulo, acciones, children } = $$props;
	head("1jvmltz", $$renderer, ($$renderer) => {
		$$renderer.title(($$renderer) => {
			$$renderer.push(`<title>${escape_html(titulo)} · Diccionario ckunsa</title>`);
		});
	});
	$$renderer.push(`<a class="vista__salto" href="#contenido">Saltar al contenido</a> <div class="vista"><header class="vista__encabezado"><div class="vista__titulos"><h1 class="vista__titulo">${escape_html(titulo)}</h1> `);
	if (subtitulo) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<p class="vista__subtitulo">${escape_html(subtitulo)}</p>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--></div> `);
	if (acciones) {
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div class="vista__acciones">`);
		acciones($$renderer);
		$$renderer.push(`<!----></div>`);
	} else $$renderer.push("<!--[-1-->");
	$$renderer.push(`<!--]--></header> <main class="vista__contenido" id="contenido">`);
	children($$renderer);
	$$renderer.push(`<!----></main> <footer class="vista__pie"><p>El ckunsa es patrimonio del pueblo lickanantay. <a href="/fuentes">Fuentes y créditos</a></p></footer></div>`);
}
//#endregion
//#region src/lib/componentes/CitaFuente.svelte
function CitaFuente($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { fuente, formato = "completa" } = $$props;
		if (formato === "compacta") {
			$$renderer.push("<!--[0-->");
			$$renderer.push(`<a class="cita cita--compacta"${attr("href", `/fuentes#${stringify(fuente.id)}`)}>${escape_html(fuente.cita_corta)}</a>`);
		} else {
			$$renderer.push("<!--[-1-->");
			$$renderer.push(`<div class="cita cita--completa"${attr("id", fuente.id)}><p class="cita__texto">${escape_html(fuente.cita)}</p> <p class="cita__licencia">Licencia: ${escape_html(fuente.licencia)} `);
			if (fuente.url) {
				$$renderer.push("<!--[0-->");
				$$renderer.push(`· <a${attr("href", fuente.url)} rel="noreferrer">${escape_html(fuente.url)}</a>`);
			} else $$renderer.push("<!--[-1-->");
			$$renderer.push(`<!--]--></p></div>`);
		}
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
export { AppViewLayout as n, CitaFuente as t };
