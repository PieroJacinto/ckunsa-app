export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["data/entradas.v1.json","data/fuentes.v1.json","data/manifest.json","data/morfemas.v1.json","fonts/Andika-Regular-subset.woff2","fonts/caracteres.txt","fonts/OFL.txt","fonts/README.md","robots.txt"]),
	mimeTypes: {".json":"application/json",".woff2":"font/woff2",".txt":"text/plain",".md":"text/markdown"},
	_: {
		client: {start:"_app/immutable/entry/start.Dsxclloi.js",app:"_app/immutable/entry/app.-PmD43N5.js",imports:["_app/immutable/entry/start.Dsxclloi.js","_app/immutable/chunks/CBQKDko8.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/entry/app.-PmD43N5.js","_app/immutable/chunks/jQKTzi_i.js","_app/immutable/chunks/HclGiUj8.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/4.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/palabra/[id]",
				pattern: /^\/palabra\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/fuentes/"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
