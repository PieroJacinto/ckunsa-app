
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/fuentes" | "/grafia" | "/indice" | "/lengua" | "/palabra" | "/palabra/[id]" | "/proyecto";
		RouteParams(): {
			"/palabra/[id]": { id: string }
		};
		LayoutParams(): {
			"/": { id?: string | undefined };
			"/fuentes": Record<string, never>;
			"/grafia": Record<string, never>;
			"/indice": Record<string, never>;
			"/lengua": Record<string, never>;
			"/palabra": { id?: string | undefined };
			"/palabra/[id]": { id: string };
			"/proyecto": Record<string, never>
		};
		Pathname(): "/" | "/fuentes/" | "/grafia/" | "/indice/" | "/lengua/" | `/palabra/${string}/` & {} | "/proyecto/";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/data/entradas.v1.json" | "/data/fuentes.v1.json" | "/data/manifest.json" | "/data/morfemas.v1.json" | "/fonts/Andika-Regular-subset.woff2" | "/fonts/caracteres.txt" | "/fonts/OFL.txt" | "/fonts/README.md" | "/robots.txt" | string & {};
	}
}